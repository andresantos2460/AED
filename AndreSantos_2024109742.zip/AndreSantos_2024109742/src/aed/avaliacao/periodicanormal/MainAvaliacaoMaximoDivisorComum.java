package aed.avaliacao.periodicanormal;

public class MainAvaliacaoMaximoDivisorComum {

    public static void main(String[] args) {
        MaximoDivisorComum.apresentar(1,-1);
        MaximoDivisorComum.apresentar(0,2);
        MaximoDivisorComum.apresentar(16,8);
        MaximoDivisorComum.apresentar(256,32);
    }
}
