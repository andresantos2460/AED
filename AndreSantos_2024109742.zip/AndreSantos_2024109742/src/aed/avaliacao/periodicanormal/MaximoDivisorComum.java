package aed.avaliacao.periodicanormal;

public class MaximoDivisorComum {

    public static int executar(int a,int b){


        if(b<0 ||a<=0){
            throw new IllegalArgumentException("Valor Inválido");
        }

        if(b==0 && a>0){
            return a;
        }


        return executar(b,a%b);



    }

    public static void apresentar(int a,int b) {
        try {
            System.out.println("valor a:"+a+", valor b:"+b+"="+executar(a,b));
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }


    }
