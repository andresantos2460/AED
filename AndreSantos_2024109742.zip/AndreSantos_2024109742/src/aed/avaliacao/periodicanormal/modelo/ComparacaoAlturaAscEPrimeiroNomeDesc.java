package aed.avaliacao.periodicanormal.modelo;

import aed.Comparacao;

public enum ComparacaoAlturaAscEPrimeiroNomeDesc implements Comparacao<Contacto> {
    CRITERIO;

    @Override
    public int comparar(Contacto o1, Contacto o2) {

        int comp=Integer.compare(o1.getAltura(), o2.getAltura());

        if(comp!=0){
            return comp;
        }
        return -o1.getPrimeiroNome().compareTo(o2.getPrimeiroNome());
    }
}
