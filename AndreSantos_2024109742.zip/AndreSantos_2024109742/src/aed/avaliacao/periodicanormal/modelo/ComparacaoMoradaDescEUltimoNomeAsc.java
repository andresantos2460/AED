package aed.avaliacao.periodicanormal.modelo;

import aed.Comparacao;

public enum ComparacaoMoradaDescEUltimoNomeAsc implements Comparacao<Contacto> {
    CRITERIO;

    @Override
    public int comparar(Contacto o1, Contacto o2) {

        int comp=-(o1.getMorada().compareTo(o2.getMorada()));

        if(comp!=0){
            return comp;
        }
        return o1.getUltimoNome().compareTo(o2.getUltimoNome());
    }
}
