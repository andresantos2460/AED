package aed.avaliacao.periodicanormal.modelo;

import aed.colecoes.iteraveis.IteradorIteravelDuplo;
import aed.colecoes.iteraveis.associativas.estruturas.TabelaHashOrdenada;
import aed.colecoes.iteraveis.lineares.naoordenadas.estruturas.ListaDuplaNaoOrdenada;
import aed.colecoes.iteraveis.lineares.ordenadas.estruturas.ListaDuplaOrdenada;

public enum GestorContactos {
    INSTANCIA;
    public static final IteradorIteravelDuplo<Contacto> ITERADOR_ITERAVEL_DUPLO_VAZIO = new ListaDuplaNaoOrdenada<Contacto>().iterador();
    private ListaDuplaOrdenada<Contacto> contactos;
    private TabelaHashOrdenada<Integer,GestorContactosAltura> contactosPorAltura;

    GestorContactos() {
        contactos=new ListaDuplaOrdenada<>(ComparacaoAlturaAscEPrimeiroNomeDesc.CRITERIO);
        contactosPorAltura=new TabelaHashOrdenada<>(ComparacaoAlturaAsc.CRITERIO,4);
    }

    public IteradorIteravelDuplo<Contacto> getContactos() {
        // todo 3.a)
        return contactos.iterador();
    }

    public IteradorIteravelDuplo<Contacto> getContactos(int altura) {
        GestorContactosAltura gestorAltura=contactosPorAltura.consultar(altura);

        return gestorAltura==null? ITERADOR_ITERAVEL_DUPLO_VAZIO :gestorAltura.iterador();
    }

    public IteradorIteravelDuplo<Contacto> getContactos(int alturaInicial, int alturaFinal) {
        // todo 3.c)
        return new Iterador(alturaInicial,alturaFinal);
    }

    public int getAmplitudeAlturas() {
        Contacto contactoMaximo=contactos.iterador().recuar();
        Contacto contactoMinimo=contactos.iterador().avancar();

        return contactoMaximo.getAltura()-contactoMinimo.getAltura();
    }

    public void inserir(Contacto contacto) {
        // todo 3.e)
        contactos.inserir(contacto);
        int altura = contacto.getAltura();

        GestorContactosAltura gestorAltura=contactosPorAltura.consultar(altura);

        if(gestorAltura==null){
            gestorAltura=new GestorContactosAltura(altura);
            contactosPorAltura.inserir(altura,gestorAltura);
        }
        gestorAltura.inserir(contacto);



    }

    private class Iterador implements IteradorIteravelDuplo<Contacto>{
        private IteradorIteravelDuplo<GestorContactosAltura> iteradorGestores;
        private IteradorIteravelDuplo<Contacto> iteradorContactos;

        public Iterador(Integer alturaInicial, Integer alturaFinal) {
            iteradorGestores = contactosPorAltura.consultarValores(alturaInicial,alturaFinal);
            iteradorContactos=ITERADOR_ITERAVEL_DUPLO_VAZIO;
        }

        @Override
        public boolean podeRecuar() {
            if(iteradorGestores.podeRecuar()||iteradorContactos.podeRecuar()){
                return true;
            }
            return false;
        }

        @Override
        public Contacto recuar() {
            if(!iteradorContactos.podeRecuar()){
                iteradorContactos=iteradorGestores.recuar().iterador();
            }
            return iteradorContactos.recuar();
        }

        @Override
        public void reiniciar() {
            iteradorGestores.reiniciar();
            iteradorContactos=ITERADOR_ITERAVEL_DUPLO_VAZIO;
        }

        @Override
        public Contacto corrente() {

            return iteradorContactos.corrente();
        }

        @Override
        public boolean podeAvancar() {
            if(iteradorContactos.podeAvancar()||iteradorGestores.podeAvancar()){
                return true;
            }
            return false;
        }

        @Override
        public Contacto avancar() {
            if(!iteradorContactos.podeAvancar()){
                iteradorContactos = iteradorGestores.avancar().iterador();
            }
            return  iteradorContactos.avancar();
        }
    }

}
