package aed.avaliacao.periodicanormal.modelo;

import aed.colecoes.iteraveis.IteradorIteravelDuplo;
import aed.colecoes.iteraveis.lineares.ordenadas.estruturas.ListaDuplaOrdenada;
import java.io.Serializable;
import java.util.Objects;

public class GestorContactosAltura implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer altura;
	private ListaDuplaOrdenada<Contacto> contactos;

	public GestorContactosAltura(Integer altura) {
		this.altura = altura;
		this.contactos = new ListaDuplaOrdenada<>(ComparacaoMoradaDescEUltimoNomeAsc.CRITERIO);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		GestorContactosAltura obj = (GestorContactosAltura) o;
		return Objects.equals(altura, obj.altura);
	}

	@Override
	public int hashCode () {
		return Objects.hash(altura);
	}

	@Override
	public String toString() {
		return " (" + altura + ", " + contactos + ")";
	}

	public IteradorIteravelDuplo<Contacto> iterador() {
		return contactos.iterador();
	}

	public void inserir(Contacto contacto) {
		contactos.inserir(contacto);
	}
}